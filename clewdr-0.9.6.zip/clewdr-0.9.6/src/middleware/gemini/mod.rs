mod request;

pub use request::{GeminiContext, GeminiOaiPreprocess, GeminiPreprocess};
