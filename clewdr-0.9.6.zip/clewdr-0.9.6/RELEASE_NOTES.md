# v0.9.6

## Improvements

- Support undocumented `x-goog-api-key` header for Google AI Studio.
